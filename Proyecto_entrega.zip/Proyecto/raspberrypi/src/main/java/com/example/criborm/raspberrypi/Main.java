package com.example.criborm.raspberrypi;

import com.google.api.core.ApiFuture;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.WriteResult;
import com.google.cloud.storage.Acl;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.FirestoreClient;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import io.grpc.LoadBalancerRegistry;
import io.grpc.internal.PickFirstLoadBalancerProvider;

public class Main {

    public static String PATH_TO_CREDENTIALS =
            "./proyecto-iot-23768.json";
    public static String BUCKET = "proyecto-iot-23768.appspot.com";

    static Storage storage;

    public static void main(String[] args){
        System.out.println("¡Hola Raspberry Pi!");

        LoadBalancerRegistry.getDefaultRegistry()
                .register(new PickFirstLoadBalancerProvider());
        try {
            FirebaseOptions options = FirebaseOptions.builder()
                    .setCredentials(GoogleCredentials.fromStream(
                            new FileInputStream(PATH_TO_CREDENTIALS)))
                    .build();
            FirebaseApp.initializeApp(options);
        } catch (IOException e) {
            e.printStackTrace();
        }

        MqttClient client;

        final String TAG = "MQTT";

        final int qos = 1;
        final String broker = "tcp://test.mosquitto.org:1883";
        final String clientId = "Test138999";


        try {
            client = new MqttClient(broker, clientId, new MemoryPersistence());
            // connect options
            MqttConnectOptions options = new MqttConnectOptions();
            options.setConnectionTimeout(60);
            options.setKeepAliveInterval(60);
            // setup callback
            client.setCallback(new MqttCallback() {

                public void connectionLost(Throwable cause) {
                    System.out.println("connectionLost: " + cause.getMessage());
                }

                public void messageArrived(String topic, MqttMessage message) {
                    System.out.println("topic: " + topic);
                    System.out.println("Qos: " + message.getQos());
                    System.out.println("message content: " + new String(message.getPayload()));
                    // 2. SI LLEGA POR EJEMPLO HABITACION METE HABITACION EN FIREBASE sensores/sensorLugar -> "habitacion"
                    if(new String(message.getPayload()).equals("habitacion")){
                        guardarFirestore("sensorLugar", message.toString());
                    }
                    else if(new String(message.getPayload()).equals("salon")){
                        guardarFirestore("sensorLugar", message.toString());
                    }
                    else if(new String(message.getPayload()).equals("tomarFoto")){
                        subirFichero(PATH_TO_CREDENTIALS, "carpeta/raspberry.json");
                    }
                    else{
                        guardarFirestore("sensorTemp", message.toString());
                    }


                }

                public void deliveryComplete(IMqttDeliveryToken token) {
                    System.out.println("deliveryComplete---------" + token.isComplete());
                }

            });
            client.connect(options);
            // 1. EL TOPIC SIEMPRE PROYECTO/SENSORES
            client.subscribe("proyecto/sensores", qos);

            storage = StorageOptions.newBuilder()
                    .setCredentials(ServiceAccountCredentials.fromStream(
                            new FileInputStream(PATH_TO_CREDENTIALS)))
                    .build()
                    .getService();


        } catch (Exception e) {
            e.printStackTrace();
        }
       // subirFichero(PATH_TO_CREDENTIALS, "carpeta/raspberry.json");




    }


    static private void subirFichero(String fichero, String referencia) {
        try {
            BlobId blobId = BlobId.of(BUCKET, referencia);
            BlobInfo blobInfo = BlobInfo.newBuilder(blobId).build();
            storage.create(blobInfo, Files.readAllBytes(Paths.get(fichero)));
            //Da acceso al fichero a través de https. la URL es
            //https://storage.googleapis.com/BUCKET/nombre_recurso
            storage.createAcl(blobId, Acl.of(Acl.User.ofAllUsers(),
                    Acl.Role.READER));
            System.out.println("Fichero subido: " + referencia);
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    static void guardarFirestore(String documento, String titulo){
        Firestore db = FirestoreClient.getFirestore();
        DocumentReference docRef = db.collection("sensores").document(documento);
        Map<String, Object> data = new HashMap<>();
        data.put("lectura", titulo);
        data.put("tiempo", System.currentTimeMillis());
        ApiFuture<WriteResult> result = docRef.set(data); //escritura asíncrona
        try { //al añadir result.get() bloquemos hasta respuesta
            System.out.println("Tiempo subida: "+result.get().getUpdateTime());
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }
}