package es.upv.iot.proyecto.datos;

import java.util.ArrayList;
import java.util.List;

public class Hogar {
    private String direccion;
    private String localidad;
    private Anciano anciano;
    private List<String> usuariosAutorizados;

    public Hogar(){}

    public Hogar(String direccion, String localidad) {
        this.direccion = direccion;
        this.localidad = localidad;
        this.anciano = new Anciano();
        this.usuariosAutorizados = new ArrayList<>();
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public Anciano getAnciano() {
        return anciano;
    }

    public void setAnciano(Anciano anciano) {
        this.anciano = anciano;
    }

    public List<String> getUsuariosAutorizados() {
        return usuariosAutorizados;
    }

    public void setUsuariosAutorizados(List<String> usuariosAutorizados) {
        this.usuariosAutorizados = usuariosAutorizados;
    }

    public void añadirUsuarioAutorizado(String correo){
        this.usuariosAutorizados.add(correo);
    }
}
