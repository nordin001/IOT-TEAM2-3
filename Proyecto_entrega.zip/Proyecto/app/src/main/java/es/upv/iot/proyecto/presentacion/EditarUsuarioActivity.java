package es.upv.iot.proyecto.presentacion;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;

import es.upv.iot.proyecto.databinding.ActivityEditarUsuarioBinding;
import es.upv.iot.proyecto.datos.Usuario;
import es.upv.iot.proyecto.modelo.Usuarios;

public class EditarUsuarioActivity extends AppCompatActivity {

    ActivityEditarUsuarioBinding binding;

    String nombre;
    String apellidos;
    String telefono;

    EditText nombreET;
    EditText apellidosET;
    EditText telefonoET;

    Usuario usuario;
    private static final int SOLICITUD_PERMISO_WRITE_CALL_LOG = 0;
    Activity activity;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditarUsuarioBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        activity = this;

        //ActionBar
        androidx.appcompat.app.ActionBar ab = getSupportActionBar();
        ab.setTitle("GrandHome");
        ab.setSubtitle("Editar perfil");
        ab.setDisplayHomeAsUpEnabled(true);


        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("usuarios").document(user.getEmail()).get()
                .addOnCompleteListener(
                        new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task){
                                if (task.isSuccessful()) {
                                    usuario = task.getResult().toObject(Usuario.class);
                                     nombre = task.getResult().getString("nombre");
                                     apellidos = task.getResult().getString("apellidos");
                                     telefono =  task.getResult().getString("telefono");

                                    nombreET = binding.nombreEditar;
                                    if(nombre != null){
                                        nombreET.setText(nombre);
                                    }
                                    apellidosET = binding.apellidosEditar;
                                    if(apellidos != null){
                                        apellidosET.setText(apellidos);
                                    }
                                    telefonoET = binding.telefonoEditar;
                                    if(telefono != null){
                                        telefonoET.setText(telefono);
                                    }

                                        binding.foto.setBackground(null);
                                        StorageReference storageRef = FirebaseStorage.getInstance().getReference();
                                        storageRef.child(usuario.getCorreo() + "/" + "perfil").getBytes(Long.MAX_VALUE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                                            @Override
                                            public void onSuccess(byte[] bytes) {
                                                // Use the bytes to display the image
                                                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                                                binding.foto.setImageBitmap(bitmap);
                                            }
                                        }).addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception exception) {
                                                // Handle any errors
                                            }
                                        });



                                } else {
                                    Log.e("Firestore", "Error al leer", task.getException());
                                }
                            }
                        });

        binding.btnGuardarCambios.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                usuario.setCorreo(user.getEmail());

                if(nombreET != null) {
                    usuario.setNombre(nombreET.getText().toString());
                }
                if(apellidosET != null) {
                    usuario.setApellidos(apellidosET.getText().toString());
                }
                if(telefonoET != null) {
                    usuario.setTelefono(telefonoET.getText().toString());
                }
                Usuarios usuarios = new Usuarios();
                usuarios.actualiza(user.getEmail(), usuario);
                Log.d("TAG", usuario.toString());
                finish();
            }
        });

        binding.foto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ActivityCompat.checkSelfPermission(activity, Manifest.permission
                        .READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                            galeria();
                }else {
                        solicitarPermiso(Manifest.permission.READ_EXTERNAL_STORAGE, "Sin el permiso"+
                                        " ACCEDER AL ALMACENAMIENTO LOCAL no puedo cambiar tu foto de perfil.",
                                SOLICITUD_PERMISO_WRITE_CALL_LOG, activity);
                    }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
       // ponerFoto(binding.foto, lugar.getFoto());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == android.R.id.home) {
            Intent intent = new Intent(this, UsuarioActivity.class);
            startActivity(intent);
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    public void galeria() {
        String action;
            if (android.os.Build.VERSION.SDK_INT >= //API19
                    android.os.Build.VERSION_CODES.KITKAT) {
                action = Intent.ACTION_OPEN_DOCUMENT;
            } else {
                action = Intent.ACTION_PICK;
            }
            Intent intent = new Intent(action,
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            galeriaLauncher.launch(intent);
        }




    ActivityResultLauncher<Intent> galeriaLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        // Create a storage reference from our app
                        StorageReference storageRef = FirebaseStorage.getInstance().getReference();

                        Uri file = Uri.parse(result.getData().getDataString());
                        StorageReference riversRef = storageRef.child(usuario.getCorreo() + "/"+"perfil");
                        UploadTask uploadTask;
                        uploadTask = riversRef.putFile(file);

// Register observers to listen for when the download is done or if it fails
                        uploadTask.addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                // Handle unsuccessful uploads
                            }
                        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                // taskSnapshot.getMetadata() contains file metadata such as size, content-type, etc.
                                // ...
                            }
                        });


                        ponerFoto();
                    } else {
                        Toast.makeText(EditarUsuarioActivity.this,
                                "Foto no cargada", Toast.LENGTH_LONG).show();
                    }
                }
            });

    protected void ponerFoto() {


                binding.foto.setBackground(null);
                StorageReference storageRef = FirebaseStorage.getInstance().getReference();
                storageRef.child(usuario.getCorreo() + "/" + "perfil").getBytes(Long.MAX_VALUE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                    @Override
                    public void onSuccess(byte[] bytes) {
                        // Use the bytes to display the image
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                        binding.foto.setImageBitmap(bitmap);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Handle any errors
                    }
                });



    }
    public static void solicitarPermiso(final String permiso, String
            justificacion, final int requestCode, final Activity actividad) {
        if (ActivityCompat.shouldShowRequestPermissionRationale(actividad,
                permiso)){
            new AlertDialog.Builder(actividad)
                    .setTitle("Solicitud de permiso")
                    .setMessage(justificacion)
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            ActivityCompat.requestPermissions(actividad,
                                    new String[]{permiso}, requestCode);
                        }}).show();
        } else {
            ActivityCompat.requestPermissions(actividad,
                    new String[]{permiso}, requestCode);
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[]
            permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if (requestCode == SOLICITUD_PERMISO_WRITE_CALL_LOG) {
            if (grantResults.length== 1 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                galeria();
            } else {
                Toast.makeText(this, "Sin el permiso, no puedo realizar la " +
                        "acción", Toast.LENGTH_SHORT).show();
            }
        }
    }

}
