package es.upv.iot.proyecto.modelo;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

import es.upv.iot.proyecto.databinding.ElementoListaBinding;
import es.upv.iot.proyecto.datos.Hogar;
import es.upv.iot.proyecto.datos.Usuario;

public class AdaptadorHogares extends
        RecyclerView.Adapter<AdaptadorHogares.ViewHolder> {
    public HogaresLista hogares; // Lista de lugares a mostrar
    protected View.OnClickListener onClickListener;

    public AdaptadorHogares(HogaresLista hogares) {
        this.hogares = hogares;
        Log.d("TAG", Integer.toString(hogares.tamaño()));

    }
    //Creamos nuestro ViewHolder, con los tipos de elementos a modificar
    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView nombre, direccion;
        public ImageView foto;

        public ViewHolder(ElementoListaBinding itemView) {
            super(itemView.getRoot());
            nombre = itemView.nombre;
            direccion = itemView.direccion;
            foto = itemView.foto;

        }
        // Personalizamos un ViewHolder a partir de un lugar
        public void personaliza(Hogar hogar) {
            nombre.setText(hogar.getDireccion());
            direccion.setText(hogar.getLocalidad());
        }
    }
    // Creamos el ViewHolder con la vista de un elemento sin personalizar
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflamos la vista desde el xml
        ElementoListaBinding v = ElementoListaBinding.inflate(LayoutInflater.from(
                parent.getContext()), parent, false);
        v.getRoot().setOnClickListener(onClickListener);
        return new AdaptadorHogares.ViewHolder(v);
    }
    // Usando como base el ViewHolder y lo personalizamos
    @Override
    public void onBindViewHolder(ViewHolder holder, int posicion) {
        Hogar hogar = hogares.elemento(posicion);
        holder.personaliza(hogar);
    }
    // Indicamos el número de elementos de la lista
    @Override public int getItemCount() {
        return hogares.tamaño();
    }

    public void setOnItemClickListener(View.OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }


}

