package es.upv.iot.proyecto.presentacion;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.util.LruCache;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.Volley;
import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import es.upv.iot.proyecto.Aplicacion;
import es.upv.iot.proyecto.R;
import es.upv.iot.proyecto.databinding.ActivityUsuarioBinding;
import es.upv.iot.proyecto.datos.Usuario;
import es.upv.iot.proyecto.modelo.Usuarios;

public class UsuarioActivity extends AppCompatActivity {

    ActivityUsuarioBinding binding;
    FirebaseUser user;
    Usuarios usuarios;
    Activity actividad;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUsuarioBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        user = FirebaseAuth.getInstance().getCurrentUser();
        usuarios = new Usuarios();
        actividad = this;



        //ActionBar
        androidx.appcompat.app.ActionBar ab = getSupportActionBar();
        ab.setTitle("GrandHome");
        ab.setSubtitle("Mi perfil");
        ab.setDisplayHomeAsUpEnabled(true);


    }

    @Override
    protected void onResume() {
        super.onResume();
        actualizaVistas();
    }

    public void actualizaVistas(){
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("usuarios").document(user.getEmail()).get()
                .addOnCompleteListener(
                        new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task){
                                if (task.isSuccessful()) {
                                    String nombre = task.getResult().getString("nombre");
                                    String correo = task.getResult().getString("correo");
                                    String apellidos = task.getResult().getString("apellidos");
                                    String telefono = task.getResult().getString("telefono");

                                    Usuario usuario = task.getResult().toObject(Usuario.class);

                                    TextView nombreTV = binding.nombre;
                                    if(nombre != null){
                                        nombreTV.setText(nombre);
                                    }
                                    TextView correoTV = binding.correo;
                                    if(correo != null){
                                        correoTV.setText(String.format("   %s", correo));
                                    }
                                    TextView apellidosTV = binding.apellidos;
                                    if(apellidos != null){
                                        apellidosTV.setText(String.format(" %s", apellidos));
                                    }

                                    TextView telefonoTV = binding.telefono;
                                    if(telefono != null){
                                        telefonoTV.setText(String.format("   %s", telefono));
                                    }


                                        binding.foto.setBackground(null);
                                        StorageReference storageRef = FirebaseStorage.getInstance().getReference();
                                        storageRef.child(usuario.getCorreo() + "/" + "perfil").getBytes(Long.MAX_VALUE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                                            @Override
                                            public void onSuccess(byte[] bytes) {
                                                // Use the bytes to display the image
                                                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                                                binding.foto.setImageBitmap(bitmap);
                                            }
                                        }).addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception exception) {
                                                // Handle any errors
                                            }
                                        });




                                } else {
                                    Log.e("Firestore", "Error al leer", task.getException());
                                }
                            }
                        });
    }

    public void cerrarSesion(View view) {
        AuthUI.getInstance().signOut(getApplicationContext())
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Intent i = new Intent(
                                getApplicationContext (), CustomLoginActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                                | Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        finish();
                    }
                });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.menu_usuario, menu);
            return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.menu_usuario) {
            Intent intent = new Intent(this, EditarUsuarioActivity.class);
            startActivity(intent);
        }
        if (id == android.R.id.home) {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            db.collection("usuarios").document(user.getEmail()).get()
                    .addOnCompleteListener(
                            new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task){
                                    if (task.isSuccessful()) {
                                        Usuario usuario = task.getResult().toObject(Usuario.class);
                                        if(usuario.getHogares().size() == 0){
                                            Intent intent = new Intent(actividad, MainActivity.class);
                                            startActivity(intent);
                                            finish();
                                        }else if(usuario.getHogares().size() == 1){
                                            Intent intent = new Intent(actividad, VistaHogarActivity.class);
                                            startActivity(intent);
                                            finish();
                                        }else if(usuario.getHogares().size() >= 2){
                                            Intent intent = new Intent(actividad, ListaHogaresActivity.class);
                                            startActivity(intent);
                                            finish();
                                        }
                                    } else {
                                        Log.e("Firestore", "Error al leer", task.getException());
                                    }
                                }
                            });



        }

        return super.onOptionsItemSelected(item);
    }



}

