package es.upv.iot.proyecto.presentacion;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import es.upv.iot.proyecto.R;
import es.upv.iot.proyecto.databinding.ActivityCompartirHogarBinding;
import es.upv.iot.proyecto.datos.Usuario;
import es.upv.iot.proyecto.modelo.Hogares;

public class CompartirHogarActivity extends AppCompatActivity {
    ActivityCompartirHogarBinding  binding;
    Hogares hogares;
    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCompartirHogarBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        hogares = new Hogares();

    binding.btnCompartirHogar.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            db.collection("usuarios").document(user.getEmail()).get()
                    .addOnCompleteListener(
                            new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task){
                                    if (task.isSuccessful()) {
                                        Usuario usuario = task.getResult().toObject(Usuario.class);
                                        EditText correoDestino = binding.correoEdit;
                                        FirebaseFirestore db = FirebaseFirestore.getInstance();
                                        try {
                                            db.collection("usuarios").document(correoDestino.getText().toString()).get()
                                                    .addOnCompleteListener(
                                                            new OnCompleteListener<DocumentSnapshot>() {
                                                                @Override
                                                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                                                    if (task.isSuccessful()) {
                                                                        Usuario usuarioDestino = task.getResult().toObject(Usuario.class);
                                                                        if(usuarioDestino != null){
                                                                            usuarioDestino.añadirHogar(usuario.getHogares().get(0));
                                                                            db.collection("usuarios").document(correoDestino.getText().toString()).set(usuarioDestino);
                                                                            ImageView esCompartido = binding.esCompartido;
                                                                            esCompartido.setBackgroundResource(R.drawable.ic_baseline_check_24);
                                                                            TextView tvError = binding.tvError;
                                                                            tvError.setText("Hogar compartido con exito!");
                                                                        }else {
                                                                            ImageView esCompartido = binding.esCompartido;
                                                                            esCompartido.setBackgroundResource(R.drawable.ic_baseline_error_outline_24);
                                                                            TextView tvError = binding.tvError;
                                                                            tvError.setText("No se encuentra el usuario con quien quieres compartir este hogar.");
                                                                        }

                                                                    } else {
                                                                        Log.e("Firestore", "Error al leer", task.getException());
                                                                    }
                                                                }
                                                            });

                                        }
                                        catch(Exception e) {
                                            ImageView esCompartido = binding.esCompartido;
                                            esCompartido.setBackgroundResource(R.drawable.ic_baseline_error_outline_24);
                                            TextView tvError = binding.tvError;
                                            tvError.setText("No se encuentra el usuario con quien quieres compartir este hogar.");
                                        }
                                    } else {
                                        Log.e("Firestore", "Error al leer", task.getException());
                                    }
                                }
                            });

        }
    });

    }
}
