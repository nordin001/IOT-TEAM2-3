package es.upv.iot.proyecto.datos;

public class Anciano {
    private String nombre;

    public Anciano() {

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
