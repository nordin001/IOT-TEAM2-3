package es.upv.iot.proyecto.presentacion;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import es.upv.iot.proyecto.databinding.ActivityRegistroBinding;

public class RegistroActivity extends AppCompatActivity {

private ActivityRegistroBinding binding;
private Activity actividad;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegistroBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        actividad = this;


        binding.crearCuentaBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                if(verificaCampos()){
                    Intent intent = new Intent();
                    intent.putExtra("email", binding.correoRegistro.getText());
                    intent.putExtra("pass", binding.contraseARegistro.getText());
                    setResult(RESULT_OK, intent);
                    finish();
                }

            }
        });



        binding.mostrarPassBtnRegistro.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                if (arg1.getAction()==MotionEvent.ACTION_DOWN)
                    binding.contraseARegistro.setTransformationMethod(null);
                else
                    binding.contraseARegistro.setTransformationMethod(new PasswordTransformationMethod());
                return true;
            }
        });
        binding.mostrarPassBtnRegistro2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                if (arg1.getAction()==MotionEvent.ACTION_DOWN)
                    binding.contraseA2Registro.setTransformationMethod(null);
                else
                    binding.contraseA2Registro.setTransformationMethod(new PasswordTransformationMethod());
                return true;
            }
        });

        binding.loginText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(actividad, CustomLoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }

    private boolean verificaCampos() {
        String correo = binding.correoRegistro.getText().toString();
        String contraseña = binding.contraseARegistro.getText().toString();
        String contraseña2 = binding.contraseA2Registro.getText().toString();

        if (correo.isEmpty()) {
            binding.errorTextCorreoRegistro.setText("Introduce una dirección de correo");

        } else if (!correo.matches(".+@.+[.].+")) {
            binding.errorTextCorreoRegistro.setText("Introduce una dirección de correo válida");
        }

         else if (contraseña.isEmpty()) {
            binding.errorTextCorreoRegistro.setText("");
            binding.errorTextContraseARegistro.setText("Introduce una contraseña");
        } else if(contraseña2.isEmpty()){
            binding.errorTextContraseARegistro.setText("");
            binding.errorTextContraseA2Registro.setText("vuelve a introducir la contraseña");

        } else if(!contraseña.equals(contraseña2)){
            binding.errorTextContraseA2Registro.setText("Las contraseñas no coinciden");
            binding.contraseARegistro.setText("");
            binding.contraseA2Registro.setText("");
        }
        else {
            binding.errorTextCorreoRegistro.setText("");
            binding.errorTextContraseARegistro.setText("");
            return true;
        }

        return false;
    }
}
