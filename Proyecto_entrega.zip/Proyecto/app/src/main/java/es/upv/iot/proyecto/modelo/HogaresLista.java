package es.upv.iot.proyecto.modelo;

import java.util.ArrayList;
import java.util.List;

import es.upv.iot.proyecto.datos.Hogar;
import es.upv.iot.proyecto.datos.Usuario;

public class HogaresLista {
    public List<Hogar> listaHogares;

    public HogaresLista() {
        this.listaHogares = new ArrayList<>();
    }

    public Hogar elemento(int id) {
        return listaHogares.get(id);
    }

    public void añade(Hogar hogar) {
        listaHogares.add(hogar);
    }

    public int nuevo() {
        Hogar hogar = new Hogar();
        listaHogares.add(hogar);
        return listaHogares.size()-1;
    }

    public void borrar(int id) {
        listaHogares.remove(id);
    }

    public int tamaño() {
        return listaHogares.size();
    }
    public void actualiza(int id, Hogar hogar) {
        listaHogares.set(id, hogar);
    }
}
