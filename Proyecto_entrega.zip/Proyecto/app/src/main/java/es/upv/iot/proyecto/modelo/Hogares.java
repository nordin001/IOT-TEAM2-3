package es.upv.iot.proyecto.modelo;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import es.upv.iot.proyecto.datos.Hogar;
import es.upv.iot.proyecto.datos.Usuario;
import es.upv.iot.proyecto.modelo.UsuariosAsinc;
import es.upv.iot.proyecto.presentacion.ListaHogaresActivity;
import es.upv.iot.proyecto.presentacion.VistaHogarActivity;

public class Hogares {
    private CollectionReference hogares;
    private CollectionReference usuarios;
    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();



    public Hogares() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        hogares = db.collection("hogares");
        usuarios = db.collection("usuarios");
    }

    public void mostrarHogar(Activity actividad, int pos){
            Intent i = new Intent(actividad, VistaHogarActivity.class);
            i.putExtra("pos", pos);
            actividad.startActivity(i);
    }


    public void crearHogar(Activity actividad, Hogar hogar) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("usuarios").document(user.getEmail()).get()
                .addOnCompleteListener(
                        new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task){
                                if (task.isSuccessful()) {
                                    Usuario usuario = task.getResult().toObject(Usuario.class);
                                    usuario.añadirHogar(hogar.getDireccion()+user.getUid());
                                    usuarios.document(user.getEmail()).set(usuario);
                                    hogares.document(hogar.getDireccion()+user.getUid()).set(hogar);
                                    if(usuario.getHogares().size() >= 2){
                                        Intent intent = new Intent(actividad, ListaHogaresActivity.class);
                                        actividad.startActivity(intent);
                                        actividad.finish();
                                    }else if(usuario.getHogares().size() <= 1){
                                        Intent intent = new Intent(actividad, VistaHogarActivity.class);
                                        actividad.startActivity(intent);
                                        actividad.finish();
                                    }

                                } else {
                                    Log.e("Firestore", "Error al leer", task.getException());
                                }
                            }
                        });

    }


    public void compartirHogar(String correoDestino, String nombreHogar) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        try {
            db.collection("usuarios").document(correoDestino).get()
                    .addOnCompleteListener(
                            new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        Usuario usuarioDestino = task.getResult().toObject(Usuario.class);
                                        if(usuarioDestino != null){
                                            usuarioDestino.añadirHogar(nombreHogar);
                                            db.collection("usuarios").document("pepe@gmail.com").set(usuarioDestino);
                                        }

                                    } else {
                                        Log.e("Firestore", "Error al leer", task.getException());
                                    }
                                }
                            });

        }
        catch(Exception e) {
            //  Block of code to handle errors
        }



    }
}
