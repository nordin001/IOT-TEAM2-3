package es.upv.iot.proyecto.presentacion;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import es.upv.iot.proyecto.R;
import es.upv.iot.proyecto.modelo.Hogares;
import es.upv.iot.proyecto.modelo.HogaresLista;
import es.upv.iot.proyecto.modelo.Usuarios;
import es.upv.iot.proyecto.databinding.ActivityMainBinding;
import es.upv.iot.proyecto.datos.Hogar;

public class MainActivity extends AppCompatActivity {

    FirebaseUser user;
    Usuarios usuarios;
    Hogares hogares;
    ActivityMainBinding binding;
    Activity actividad;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        actividad = this;
        user = FirebaseAuth.getInstance().getCurrentUser();

        usuarios = new Usuarios();
        hogares = new Hogares();

        ActionBar ab = getSupportActionBar();
        ab.setTitle("GrandHome");






      /* ESCRIBIR FIRESTORE
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Map<String, Object> datos = new HashMap<>();
        datos.put("dato_2", 48);
        datos.put("numero", 3.14159265);
        datos.put("fecha", new Date());
        datos.put("lista", Arrays.asList(1, 2, 3));
        datos.put("null", null);
        Map<String, Object> datosAnidados = new HashMap<>();
        datosAnidados.put("a", 5);
        datosAnidados.put("b", true);
        datos.put("objectExample", datosAnidados);
        db.collection("coleccion").document("documento").set(datos);
      */
        /* LEER FIRESTORE
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("coleccion").document("documento").get()
                .addOnCompleteListener(
                        new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task){
                                if (task.isSuccessful()) {
                                    String dato1 = task.getResult().getString("dato_1");
                                    double dato2 = task.getResult().getDouble("dato_2");
                                    Log.d("Firestore", "dato 1:" + dato1 + " dato 2:" + dato2);
                                } else {
                                    Log.e("Firestore", "Error al leer", task.getException());
                                }
                            }
                        });
            */
        /*LEER FIRESTORE A CADA CAMBIO
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("coleccion").document("documento").addSnapshotListener(
                new EventListener<DocumentSnapshot>() {
                    @Override
                    public void onEvent(@Nullable DocumentSnapshot snapshot,
                                        @Nullable FirebaseFirestoreException e){
                        if (e != null) {
                            Log.e("Firestore", "Error al leer", e);
                        } else if (snapshot == null || !snapshot.exists()) {
                            Log.e("Firestore", "Error: documento no encontrado ");
                        } else {
                            Log.d("Firestore", "datos:" + snapshot.getData());
                        }
                    }
                });
*/

        binding.btnNuevoHogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(actividad, NuevoHogarActivity.class);
                startActivity(intent);
               finish();
            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();

    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.

            getMenuInflater().inflate(R.menu.menu_main, menu);
            return true;


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.menu_usuario) {
            Intent intent = new Intent(this, UsuarioActivity.class);
            startActivity(intent);
        }


        if (id == R.id.acerca_de){
            Intent intent = new Intent(this, AcercadeActivity.class);
            startActivity(intent);
        }


        if (id == R.id.cerrar_sesion) {
            cerrarSesion();
        }

        return super.onOptionsItemSelected(item);
    }

    public void cerrarSesion() {
        AuthUI.getInstance().signOut(getApplicationContext())
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Intent i = new Intent(
                                getApplicationContext (), PrincipalLoginActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                                | Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        finish();
                    }
                });
    }
}