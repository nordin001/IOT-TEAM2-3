package es.upv.iot.proyecto.modelo;

import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import es.upv.iot.proyecto.datos.Hogar;
import es.upv.iot.proyecto.datos.Usuario;
import es.upv.iot.proyecto.modelo.UsuariosAsinc;

public class Usuarios implements UsuariosAsinc {
    private CollectionReference usuarios;
    private Usuario usuario;
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

    public Usuarios() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        usuarios = db.collection("usuarios");
        usuario = new Usuario();
    }


    public void elemento(String id, final EscuchadorElemento escuchador) {
        usuarios.document(id).get().addOnCompleteListener(

                new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            Usuario usuario = task.getResult().toObject(Usuario.class);
                            escuchador.onRespuesta(usuario);
                        } else {
                            Log.e("Firebase", "Error al leer", task.getException());
                            escuchador.onRespuesta(null);
                        }
                    }
                });
    }

    public Usuario getUsuario(){
        usuarios.document(user.getEmail()).get()
                .addOnCompleteListener(
                        new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task){
                                if (task.isSuccessful()) {
                                    usuario = task.getResult().toObject(Usuario.class);
                                    Log.d("TAG", usuario.getCorreo());
                                } else {
                                    Log.e("Firestore", "Error al leer", task.getException());
                                }
                            }
                        });
        return usuario;
    }


    public void nuevo(final FirebaseUser user) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("usuarios").document(user.getEmail()).get()
                .addOnCompleteListener(
                        new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    String correoComparacion = task.getResult().getString("correo");
                                    Usuario usuario = new Usuario(user.getDisplayName(), user.getEmail());
                                    if (correoComparacion == null) {
                                        db.collection("usuarios").document(user.getEmail()).set(usuario);
                                    }
                                } else {
                                    Log.e("Firestore", "Error al leer", task.getException());
                                }
                            }
                        });
    }


    public void borrar(String id) {
        usuarios.document(id).delete();
    }

    public void actualiza(String id, Usuario usuario) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("usuarios").document(id).set(usuario);
    }

    public void tamaño(final EscuchadorTamaño escuchador) {
        usuarios.get().addOnCompleteListener(
                new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            escuchador.onRespuesta(task.getResult().size());
                        } else {
                            Log.e("Firebase", "Error en tamaño", task.getException());
                            escuchador.onRespuesta(-1);
                        }
                    }
                });
    }

    @Override
    public void actualizaHogares(String id, List<Hogar> hogares) {

    }


    public void añadirHogar(String id, Hogar hogar) {
        usuarios.document(id).get()
                .addOnCompleteListener(
                        new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    Usuario usuario = task.getResult().toObject(Usuario.class);



                                    usuarios.document(id).set(usuario);
                                } else {
                                    Log.e("Firestore", "Error al leer", task.getException());
                                }
                            }
                        });
    }

}





