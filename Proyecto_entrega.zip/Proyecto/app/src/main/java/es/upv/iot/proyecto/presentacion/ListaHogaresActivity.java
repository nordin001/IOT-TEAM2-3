package es.upv.iot.proyecto.presentacion;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import es.upv.iot.proyecto.Aplicacion;
import es.upv.iot.proyecto.R;
import es.upv.iot.proyecto.databinding.ActivityListaHogaresBinding;
import es.upv.iot.proyecto.datos.Hogar;
import es.upv.iot.proyecto.datos.Usuario;
import es.upv.iot.proyecto.modelo.AdaptadorHogares;
import es.upv.iot.proyecto.modelo.Hogares;
import es.upv.iot.proyecto.modelo.HogaresLista;
import es.upv.iot.proyecto.modelo.UsuariosAsinc;

public class ListaHogaresActivity extends AppCompatActivity {

    ActivityListaHogaresBinding binding;
    FirebaseUser user;
    private RecyclerView recyclerView;
    public AdaptadorHogares adaptador;
    Hogares hogares;
    Activity actividad;
    public HogaresLista hogaresLista = new HogaresLista();
    public Usuario usuario = new Usuario();


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityListaHogaresBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        user = FirebaseAuth.getInstance().getCurrentUser();
        hogares = new Hogares();
        actividad = this;

        //ActionBar
        androidx.appcompat.app.ActionBar ab = getSupportActionBar();
        ab.setTitle("GrandHome");
        ab.setSubtitle("Hogares");

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        try{
            db.collection("usuarios").document(user.getEmail()).get()
                    .addOnCompleteListener(
                            new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task){
                                    if (task.isSuccessful()) {
                                        usuario = task.getResult().toObject(Usuario.class);
                                        if(usuario != null){
                                            for (String h:usuario.getHogares()
                                            ) {
                                                db.collection("hogares").document(h).get()
                                                        .addOnCompleteListener(
                                                                new OnCompleteListener<DocumentSnapshot>() {
                                                                    @Override
                                                                    public void onComplete(@NonNull Task<DocumentSnapshot> task){
                                                                        if (task.isSuccessful()) {
                                                                            Hogar hogar = task.getResult().toObject(Hogar.class);
                                                                            hogaresLista.añade(hogar);
                                                                            adaptador = new AdaptadorHogares(hogaresLista);
                                                                            recyclerView = binding.content.recyclerView;
                                                                            recyclerView.setHasFixedSize(true);
                                                                            recyclerView.setLayoutManager(new LinearLayoutManager(actividad));
                                                                            recyclerView.setAdapter(adaptador);
                                                                            adaptador.setOnItemClickListener(new View.OnClickListener() {
                                                                                @Override
                                                                                public void onClick(View v) {
                                                                                    int pos= recyclerView.getChildAdapterPosition(v);
                                                                                    hogares.mostrarHogar(actividad, pos);
                                                                                }
                                                                            });
                                                                        } else {
                                                                            Log.e("Firestore", "Error al leer", task.getException());
                                                                        }
                                                                    }
                                                                });
                                            }
                                        }


                                    } else {
                                        Log.e("Firestore", "Error al leer", task.getException());
                                    }
                                }
                            });

        }catch (Exception e){

        }


    }

    @Override
    protected void onResume() {
        super.onResume();




    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

            getMenuInflater().inflate(R.menu.menu_lista_hogares, menu);
            return true;


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if(id == R.id.nuevo_hogar){
            Intent intent = new Intent(this, NuevoHogarActivity.class);
            startActivity(intent);
        }

        if (id == R.id.menu_usuario) {
            Intent intent = new Intent(this, UsuarioActivity.class);
            startActivity(intent);
        }

        if (id == R.id.acerca_de){
            Intent intent = new Intent(this, AcercadeActivity.class);
            startActivity(intent);
        }


        if (id == R.id.cerrar_sesion) {
            cerrarSesion();
        }

        return super.onOptionsItemSelected(item);
    }

    public void cerrarSesion() {
        AuthUI.getInstance().signOut(getApplicationContext())
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Intent i = new Intent(
                                getApplicationContext (), PrincipalLoginActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                                | Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        finish();
                    }
                });
    }
}
