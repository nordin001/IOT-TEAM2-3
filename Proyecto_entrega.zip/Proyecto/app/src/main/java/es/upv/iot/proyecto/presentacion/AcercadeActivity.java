package es.upv.iot.proyecto.presentacion;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import es.upv.iot.proyecto.R;

public class AcercadeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acercade);


    }
}
