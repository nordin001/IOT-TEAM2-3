package es.upv.iot.proyecto.presentacion;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.BitmapFactory;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.blautic.pikkuAcademyLib.PikkuAcademy;
import com.blautic.pikkuAcademyLib.ScanInfo;
import com.blautic.pikkuAcademyLib.ble.gatt.ConnectionState;
import com.blautic.pikkuAcademyLib.callback.AccelerometerCallback;
import com.blautic.pikkuAcademyLib.callback.ConnectionCallback;
import com.blautic.pikkuAcademyLib.callback.ScanCallback;
import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;

import es.upv.iot.proyecto.Aplicacion;
import es.upv.iot.proyecto.R;
import es.upv.iot.proyecto.databinding.ActivityVistaHogarBinding;
import es.upv.iot.proyecto.datos.Hogar;
import es.upv.iot.proyecto.datos.ServicioSensores;
import es.upv.iot.proyecto.datos.Usuario;
import es.upv.iot.proyecto.modelo.AdaptadorHogares;
import es.upv.iot.proyecto.modelo.Hogares;
import es.upv.iot.proyecto.modelo.HogaresLista;

import static es.upv.iot.proyecto.datos.mqtt.*;


public class VistaHogarActivity extends AppCompatActivity {

        ActivityVistaHogarBinding binding;
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        Hogares hogares = new Hogares();
        Usuario usuario = new Usuario();
        HogaresLista hogaresLista;
        Context contexto = this;

        private AdaptadorHogares adaptador;
        static final int NOTIFICACION_ID =1;;
        private Hogar hogar;
        PikkuAcademy pikku;
        Button escanear;
        Button connectar;
        private NotificationManager notificationManager;
        static final String CANAL_ID="mi_canal";


        androidx.appcompat.app.ActionBar ab;

        MqttClient client;

        @Override
        protected void onCreate(@Nullable Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                binding = ActivityVistaHogarBinding.inflate(getLayoutInflater());
                setContentView(binding.getRoot());
                hogaresLista = new HogaresLista();
                Aplicacion aplicacion = (Aplicacion)getApplication();
                aplicacion.VistaHogarContext = this;
                //pikku
                pikku = PikkuAcademy.getInstance(this);
                pikku.enableLog();
                //escanear.findViewById(R.id.button_scan);
                //connectar=findViewById(R.id.button_connect);
                //notificacion
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                        //String description = getString(R.string.channel_description);
                        int importance = NotificationManager.IMPORTANCE_DEFAULT;
                        NotificationChannel channel = new NotificationChannel("1", "my notification", importance);
                        //channel.setDescription(description);
                        // Register the channel with the system; you can't change the importance
                        // or other notification behaviors after this
                        NotificationManager notificationManager = getSystemService(NotificationManager.class);
                        notificationManager.createNotificationChannel(channel);
                }
                //
                binding.buttonScan.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                                binding.textScan.setText("Pulsa el botón Pikku 1 para ser scaneado");
                                pikku.scan(true, new ScanCallback() {
                                        @Override
                                        public void onScan(ScanInfo scanInfo) {
                                                pikku.saveDevice(scanInfo);
                                                // guardar dispositivo para futuras conexiones
                                                Log.d("Pikku", scanInfo.toString());
                                                binding.textScan.setText("Encontrado:"+pikku.getAddressDevice());
                                                binding.buttonConnect.setEnabled(true);
                                        }
                                });
                                binding.textConnect.setText("Conectando...");
                                pikku.connect(new ConnectionCallback() {
                                        @Override
                                        public void onConnect(ConnectionState state) {
                                                if (state == ConnectionState.CONNECTED) {
                                                        binding.textConnect.setText("Conectado: " + pikku.getAddressDevice());
                                                        binding.buttonScan.setEnabled(false);
                                                        pikku.enableReportSensors(true);
                                                        pikku.changeTransmittingPeriod(250);
                                                        pikku.readAccelerometer(new AccelerometerCallback() {
                                                                @Override
                                                                public void onReadSuccess(float x, float y, float z) {
                                                                        if (z>1.1) {
                                                                                Log.d("ALERTA","SE HA CALLIDO EL VIEJO");
                                                                                Log.d("Pikku" , "Acelerómetro: x:"+x+" y: "+y+" z: "+z);
                                                                                NotificationCompat.Builder builder = new NotificationCompat.Builder(contexto, "1")
                                                                                        .setSmallIcon(R.drawable.custom_mail_icon)
                                                                                        .setContentTitle("Alerta")
                                                                                        .setContentText("Se Ha Callido EL VIEJO")
                                                                                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                                                                                        .setAutoCancel(true);
                                                                                NotificationManagerCompat managerCompat=NotificationManagerCompat.from(contexto);
                                                                                managerCompat.notify(1,builder.build());


                                                                        }

                                                                       // Log.d("Pikku" , "Acelerómetro: x:"+x+" y: "+y+" z: "+z);

                                                                }
                                                                @Override
                                                                public void onReadAngles(float xy, float zy, float xz) {
                                                                       // Log.d("Pikku" , "Ángulos: xy:"+xy+" zy: "+zy+" xz: "+xz);
                                                                }
                                                        });
                                                }
                                        }
                                });

                        }
                });

                binding.buttonConnect.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                                new CountDownTimer(3000, 1000) {

                                        public void onTick(long millisUntilFinished) {
                                                pikku.startEngine();//Conecta vibració
                                        }

                                        public void onFinish() {
                                                pikku.stopEngine();
                                                ;}}.start();
                        }
                });


                //ActionBar
                ab = getSupportActionBar();
                ab.setTitle("GrandHome");
               // ab.setSubtitle(hogar.getDireccion());


                FirebaseFirestore db = FirebaseFirestore.getInstance();
                try{
                        db.collection("usuarios").document(user.getEmail()).get()
                                .addOnCompleteListener(
                                        new OnCompleteListener<DocumentSnapshot>() {
                                                @Override
                                                public void onComplete(@NonNull Task<DocumentSnapshot> task){
                                                        if (task.isSuccessful()) {
                                                                usuario = task.getResult().toObject(Usuario.class);
                                                                if(usuario != null){
                                                                        if(usuario.getHogares().size() == 1){
                                                                                ab.setDisplayHomeAsUpEnabled(false);
                                                                        }else if(usuario.getHogares().size() >= 2){
                                                                                ab.setDisplayHomeAsUpEnabled(true);
                                                                        }
                                                                        for (String h:usuario.getHogares()
                                                                        ) {
                                                                                db.collection("hogares").document(h).get()
                                                                                        .addOnCompleteListener(
                                                                                                new OnCompleteListener<DocumentSnapshot>() {
                                                                                                        @Override
                                                                                                        public void onComplete(@NonNull Task<DocumentSnapshot> task){
                                                                                                                if (task.isSuccessful()) {
                                                                                                                        hogar = task.getResult().toObject(Hogar.class);
                                                                                                                        hogaresLista.añade(hogar);
                                                                                                                        if(hogaresLista.tamaño() == usuario.getHogares().size()){
                                                                                                                                if(usuario.getHogares().size()<2){
                                                                                                                                        hogar = hogaresLista.elemento(0);
                                                                                                                                        actualizaVistas();
                                                                                                                                }else if(usuario.getHogares().size() >= 2){
                                                                                                                                        Bundle extras = getIntent().getExtras();
                                                                                                                                        int pos;
                                                                                                                                        pos = extras.getInt("pos", 0);
                                                                                                                                        hogar = hogaresLista.elemento(pos);
                                                                                                                                        actualizaVistas();
                                                                                                                                }
                                                                                                                        }

                                                                                                                } else {
                                                                                                                        Log.e("Firestore", "Error al leer", task.getException());
                                                                                                                }
                                                                                                        }
                                                                                                });
                                                                        }
                                                                }


                                                        } else {
                                                                Log.e("Firestore", "Error al leer", task.getException());
                                                        }


                                                }
                                        });

                }catch (Exception e){

                }


                startService(new Intent(VistaHogarActivity.this,
                        ServicioSensores.class));

                IntentFilter filtro = new IntentFilter(
                        "android.intent.action.BATTERY_LOW");
                filtro.addCategory(Intent.CATEGORY_DEFAULT);
                registerReceiver(new ReceptorAnuncio(), filtro);

/*
                db.collection("sensores").document("temperatura").addSnapshotListener(
                        new EventListener<DocumentSnapshot>() {
                                @Override
                                public void onEvent(@Nullable DocumentSnapshot snapshot,
                                                    @Nullable FirebaseFirestoreException e){
                                        if (e != null) {
                                                Log.e("Firestore", "Error al leer", e);
                                        } else if (snapshot == null || !snapshot.exists()) {
                                                Log.e("Firestore", "Error: documento no encontrado ");
                                        } else {
                                                Log.d("Firestore", "datos:" + snapshot.getData());
                                                binding.tempText.setText(snapshot.getData().values().toString() + "ºC");
                                        }
                                }
                        });
                        */

                db.collection("sensores").document("lugar").addSnapshotListener(
                        new EventListener<DocumentSnapshot>() {
                                @Override
                                public void onEvent(@Nullable DocumentSnapshot snapshot,
                                                    @Nullable FirebaseFirestoreException e){
                                        if (e != null) {
                                                Log.e("Firestore", "Error al leer", e);
                                        } else if (snapshot == null || !snapshot.exists()) {
                                                Log.e("Firestore", "Error: documento no encontrado ");
                                        } else {
                                                Log.d("Firestore", "datos:" + snapshot.getData());
                                                binding.lugarText.setText(snapshot.getData().values().toString());
                                        }
                                }
                        });

                conectarMqtt();

                binding.imageView6.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                                publicarMqtt("tomarFoto","tomarFoto");

                                Toast.makeText(getApplicationContext(), "Topic publicado",
                                        Toast.LENGTH_LONG).show();
                        }
                });


                db.collection("sensores").document("sensorTemp").addSnapshotListener(
                        new EventListener<DocumentSnapshot>() {
                                @Override
                                public void onEvent(@Nullable DocumentSnapshot snapshot,
                                                    @Nullable FirebaseFirestoreException e){
                                        if (e != null) {
                                                Log.e("Firestore", "Error al leer", e);
                                        } else if (snapshot == null || !snapshot.exists()) {
                                                Log.e("Firestore", "Error: documento no encontrado ");
                                        } else {
                                                Log.d("Firestore", "datos:" + snapshot.getData());
                                                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm");

                                                if(snapshot.get("tiempo") != null){
                                                        long timi = Long.parseLong(snapshot.get("tiempo").toString());
                                                        Date date = new Date(timi);
                                                        String time = simpleDateFormat.format(date);
                                                        String datos = snapshot.get("lectura").toString()+"ºC" + "      "+time;
                                                        binding.tempText.setText(datos);
                                                }
                                        }
                                }
                        });

                db.collection("sensores").document("sensorLugar").addSnapshotListener(
                        new EventListener<DocumentSnapshot>() {
                                @Override
                                public void onEvent(@Nullable DocumentSnapshot snapshot,
                                                    @Nullable FirebaseFirestoreException e){
                                        if (e != null) {
                                                Log.e("Firestore", "Error al leer", e);
                                        } else if (snapshot == null || !snapshot.exists()) {
                                                Log.e("Firestore", "Error: documento no encontrado ");
                                        } else {
                                                Log.d("Firestore", "datos:" + snapshot.getData());
                                                        String datos = snapshot.get("lectura").toString();
                                                        binding.lugarText.setText(datos);

                                        }
                                }
                        });


                // initialize the seekBar object
                SeekBar seekBar=findViewById(R.id.seekBar);
                // calling the seekbar event change listener
                seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        @Override
                        // increment or decrement on process changed
                        // increase the textsize
                        // with the value of progress
                        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                        }
                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {
                                // This method will automatically
                                // called when the user touches the SeekBar
                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {
                                // This method will automatically
                                // called when the user
                                // stops touching the SeekBar
                                if(seekBar.getProgress() != 0 && seekBar.getProgress() != 100){
                                        publicarMqtt("proyecto/persiana", Integer.toString(seekBar.getProgress()));
                                }
                                else if(seekBar.getProgress() == 0){
                                        publicarMqtt("proyecto/persiana", Integer.toString(1));
                                }
                                else if(seekBar.getProgress() == 100){
                                        publicarMqtt("proyecto/persiana", Integer.toString(99));
                                }

                        }
                });
        }

        public class ReceptorAnuncio extends BroadcastReceiver {
                @Override
                public void onReceive(Context context, Intent intent) {
                        stopService(new Intent(VistaHogarActivity.this,
                                ServicioSensores.class));
                }
        }


        public void actualizaVistas() {
                ab.setSubtitle(hogar.getDireccion());
        }



        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
                FirebaseFirestore db = FirebaseFirestore.getInstance();
                db.collection("usuarios").document(user.getEmail()).get()
                        .addOnCompleteListener(
                                new OnCompleteListener<DocumentSnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<DocumentSnapshot> task){
                                                if (task.isSuccessful()) {
                                                        usuario = task.getResult().toObject(Usuario.class);
                                                        if(usuario.getHogares().size()<=1) {
                                                                getMenuInflater().inflate(R.menu.menu_vista_hogar1, menu);
                                                        } else if (usuario.getHogares().size() >= 2) {
                                                                getMenuInflater().inflate(R.menu.menu_vista_hogar_varios, menu);
                                                        }
                                                } else {
                                                        Log.e("Firestore", "Error al leer", task.getException());
                                                }
                                        }
                                });
                        return true;
        }

        @Override
        public boolean onOptionsItemSelected(MenuItem item) {
                // Handle action bar item clicks here. The action bar will
                // automatically handle clicks on the Home/Up button, so long
                // as you specify a parent activity in AndroidManifest.xml.
                int id = item.getItemId();

                if(id == R.id.mapa){
                        Intent intent = new Intent(this, MapActivity.class);
                        startActivity(intent);
                }

                if(id == R.id.nuevo_hogar){
                        Intent intent = new Intent(this, NuevoHogarActivity.class);
                        startActivity(intent);
                        finish();

                }
                if(id == R.id.compartir_hogar){
                        Intent intent = new Intent(this, CompartirHogarActivity.class);
                        startActivity(intent);
                }

                if (id == R.id.menu_usuario) {
                        Intent intent = new Intent(this, UsuarioActivity.class);
                        startActivity(intent);
                }

                if (id == R.id.acerca_de){
                        Intent intent = new Intent(this, AcercadeActivity.class);
                        startActivity(intent);
                }


                if (id == R.id.cerrar_sesion) {
                        cerrarSesion();
                }

                if(id == android.R.id.home){
                        Intent intent = new Intent(this, ListaHogaresActivity.class);
                        startActivity(intent);
                        finish();
                }

                return super.onOptionsItemSelected(item);
        }



        public void cerrarSesion() {
                AuthUI.getInstance().signOut(getApplicationContext())
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                        Intent i = new Intent(
                                                getApplicationContext (), PrincipalLoginActivity.class);
                                        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                                                | Intent.FLAG_ACTIVITY_NEW_TASK
                                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                        startActivity(i);
                                        finish();
                                }
                        });
                stopService(new Intent(VistaHogarActivity.this,
                        ServicioSensores.class));
        }


        public void conectarMqtt(){
                try {
                        Log.i(TAG, "Conectando al broker " + broker);
                        client = new MqttClient(broker, "Test222", new MemoryPersistence());
                        client.connect();
                } catch (MqttException e) {
                        Log.e(TAG, "Error al conectar.", e);
                }
        }

        public void suscribirMqtt(String topic, MqttCallback listener) {
                try {
                        Log.i(TAG, "Suscrito a " + topicRoot + topic);
                        client.subscribe(topicRoot + topic, qos);
                        client.setCallback(listener);
                } catch (MqttException e) {
                        Log.e(TAG, "Error al suscribir.", e);
                }
        }


        public  void publicarMqtt(String topic, String mensageStr) {
                try {
                        MqttMessage message = new MqttMessage(mensageStr.getBytes());
                        message.setQos(qos);
                        message.setRetained(false);
                        client.publish(topic, message);
                        Log.i(TAG, "Publicando mensaje: " + topic+ "->"+mensageStr);
                } catch (MqttException e) {
                        Log.e(TAG, "Error al publicar." + e);
                }
        }

        public  void deconectarMqtt() {
                try {
                        client.disconnect();
                        Log.i(TAG, "Desconectado");
                } catch (MqttException e) {
                        Log.e(TAG, "Error al desconectar.", e);
                }
        }

        @Override
        protected void onDestroy() {
                publicarMqtt("proyecto/persiana", Integer.toString(1));
                super.onDestroy();
        }
}
