package es.upv.iot.proyecto;

import android.app.Activity;
import android.app.Application;
import android.graphics.Bitmap;
import android.util.Log;
import android.util.LruCache;

import androidx.annotation.NonNull;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.Volley;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import es.upv.iot.proyecto.datos.Hogar;
import es.upv.iot.proyecto.datos.Usuario;
import es.upv.iot.proyecto.modelo.AdaptadorHogares;
import es.upv.iot.proyecto.modelo.HogaresLista;
import es.upv.iot.proyecto.modelo.Usuarios;
import es.upv.iot.proyecto.modelo.UsuariosAsinc;
import es.upv.iot.proyecto.presentacion.VistaHogarActivity;

public class Aplicacion extends Application {

    public HogaresLista hogares = new HogaresLista();
    public Usuario usuario = new Usuario();
    public AdaptadorHogares adaptador;
    public FirebaseUser user;
    public Activity VistaHogarContext;

    @Override public void onCreate() {

        super.onCreate();
            adaptador = new AdaptadorHogares(hogares);
            VistaHogarContext = new VistaHogarActivity();


        /*
        Query query = FirebaseFirestore.getInstance().collection("hogares")
                .limit(50);
        FirestoreRecyclerOptions<Hogar> opciones = new FirestoreRecyclerOptions
                .Builder<Hogar>().setQuery(query, Hogar.class).build();
        adaptador = new AdaptadorUsuariosFirestoreUI(opciones, this);
        */

    }
}

