package es.upv.iot.proyecto.presentacion;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import es.upv.iot.proyecto.R;
import es.upv.iot.proyecto.databinding.ActivityNuevoHogarBinding;
import es.upv.iot.proyecto.datos.Hogar;
import es.upv.iot.proyecto.datos.Usuario;
import es.upv.iot.proyecto.modelo.Hogares;

public class NuevoHogarActivity extends AppCompatActivity {

    ActivityNuevoHogarBinding binding;
    FirebaseUser user;
    Activity actividad;
    Hogares hogares;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityNuevoHogarBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //ActionBar
        androidx.appcompat.app.ActionBar ab = getSupportActionBar();
        ab.setTitle("GrandHome");
        ab.setSubtitle("Nuevo Hogar");
        ab.setDisplayHomeAsUpEnabled(true);

        user = FirebaseAuth.getInstance().getCurrentUser();
        actividad = this;
        hogares = new Hogares();



        binding.btnCrearHogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText direccion = binding.direccionEdit;
                EditText ciudad = binding.localidadEdit;
                if(direccion.getText() != null && ciudad.getText() != null){
                    Hogar hogar = new Hogar(direccion.getText().toString(), ciudad.getText().toString());
                    hogares.crearHogar(actividad, hogar);
                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                    db.collection("usuarios").document(user.getEmail()).get()
                            .addOnCompleteListener(
                                    new OnCompleteListener<DocumentSnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<DocumentSnapshot> task){
                                            if (task.isSuccessful()) {
                                                Usuario usuario = task.getResult().toObject(Usuario.class);
                                                if (usuario.getHogares().size() == 1){
                                                    Intent intent = new Intent(actividad, VistaHogarActivity.class);
                                                    startActivity(intent);
                                                    finish();
                                                }else if(usuario.getHogares().size() >= 2){
                                                    Intent intent = new Intent(actividad, ListaHogaresActivity.class);
                                                    startActivity(intent);
                                                    finish();
                                                }
                                            } else {
                                                Log.e("Firestore", "Error al leer", task.getException());
                                            }
                                        }
                                    });
                }

            }
        });

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.

        getMenuInflater().inflate(R.menu.menu_vacio, menu);
        return true;


    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if(id == android.R.id.home){
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            db.collection("usuarios").document(user.getEmail()).get()
                    .addOnCompleteListener(
                            new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task){
                                    if (task.isSuccessful()) {
                                       Usuario usuario = task.getResult().toObject(Usuario.class);
                                       if(usuario.getHogares().size() == 0){
                                           Intent intent = new Intent(actividad, MainActivity.class);
                                           startActivity(intent);
                                           finish();
                                       }else if (usuario.getHogares().size() == 1){
                                           Intent intent = new Intent(actividad, VistaHogarActivity.class);
                                           startActivity(intent);
                                           finish();
                                       }else if(usuario.getHogares().size() >= 2){
                                           Intent intent = new Intent(actividad, ListaHogaresActivity.class);
                                           startActivity(intent);
                                           finish();
                                       }
                                    } else {
                                        Log.e("Firestore", "Error al leer", task.getException());
                                    }
                                }
                            });

        }

        return super.onOptionsItemSelected(item);
    }
}
