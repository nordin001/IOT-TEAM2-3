package es.upv.iot.proyecto.datos;

public class mqtt {
    public static final String TAG = "MQTT";
    public static final String topicRoot="proyecto/pir/";
    public static final int qos = 1;
    public static final String broker = "tcp://test.mosquitto.org:1883";
    public static final String clientId = "Test13444444";
}

