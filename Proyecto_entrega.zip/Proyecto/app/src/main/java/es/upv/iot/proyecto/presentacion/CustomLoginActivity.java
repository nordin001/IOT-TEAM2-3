package es.upv.iot.proyecto.presentacion;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;


import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;


import es.upv.iot.proyecto.R;
import es.upv.iot.proyecto.databinding.ActivityLoginBinding;
import es.upv.iot.proyecto.datos.Usuario;
import es.upv.iot.proyecto.modelo.Usuarios;


public class CustomLoginActivity extends AppCompatActivity {

    private FirebaseAuth auth = FirebaseAuth.getInstance();
    private ActivityLoginBinding binding;
    private Activity actividad;

    //------Declaraciones login con correo y contraseña---------------------------------------------
    private String correo = "";
    private String contraseña = "";
    private ViewGroup contenedor;
    private EditText etCorreo, etContraseña;
    private ProgressDialog dialogo;
    //----------------------------------------------------------------------------------------------
    //------Declaraciones de login con GOOGLE ------------------------------------------------------
    private static final int RC_GOOGLE_SIGN_IN = 123;
    GoogleSignInClient googleSignInClient;
    //----------------------------------------------------------------------------------------------
    //------Declaraciones de REGISTRO --------------------------------------------------------------
    private String emailRegistro;
    private String passRegistro;
    //----------------------------------------------------------------------------------------------
    //------Declaraciones de FACEBOOK --------------------------------------------------------------
    private CallbackManager callbackManager;
    private LoginButton btnFacebook;
    //----------------------------------------------------------------------------------------------


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        actividad = this;


        etCorreo = (EditText) findViewById(R.id.correo);
        etContraseña = (EditText) findViewById(R.id.contraseña);
        contenedor = (ViewGroup) findViewById(R.id.contenedor);
        dialogo = new ProgressDialog(this);
        dialogo.setTitle("Verificando usuario");
        dialogo.setMessage("Por favor espere...");
/*
        //Facebook
        callbackManager = CallbackManager.Factory.create();
        btnFacebook = (LoginButton) findViewById(R.id.facebook);
        btnFacebook.setReadPermissions("email", "public_profile");
        btnFacebook.registerCallback(callbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override public void onSuccess(LoginResult loginResult) {
                        facebookAuth(loginResult.getAccessToken());
                    }
                    @Override public void onCancel() {
                        mensaje("Cancelada autentificación con facebook");
                    }
                    @Override public void onError(FacebookException error) {
                        mensaje(error.getLocalizedMessage());
                    }
                });
*/
        verificaSiUsuarioValidado();
/*
        //Google
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(
                GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, gso);

        binding.googleBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent i = googleSignInClient.getSignInIntent();
                startActivityForResult(i, RC_GOOGLE_SIGN_IN);
            }
        });
*/
        binding.inicioSesionBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                inicioSesiónCorreo();
            }
        });

        binding.recuperarText.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                reestablecerContraseña();
            }
        });

        binding.registrateText.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(actividad, RegistroActivity.class);
                activityResultLauncher.launch(intent);
            }
        });
/*
        binding.mostrarPassBtn.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                if (arg1.getAction()==MotionEvent.ACTION_DOWN)
                    binding.contraseA.setTransformationMethod(null);
                else
                    binding.contraseA.setTransformationMethod(new PasswordTransformationMethod());
                return true;
            }
        });
*/
    }



    ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();

                        emailRegistro = data.getExtras().get("email").toString();
                        passRegistro = data.getExtras().get("pass").toString();
                        registroCorreo();
                    }
                    if (result.getResultCode() != Activity.RESULT_OK) {
                        Intent data = result.getData();

                    }
                }
            });



/*
    @Override public void onActivityResult(int requestCode, int resultCode,
                                           Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_GOOGLE_SIGN_IN) {
            Task<GoogleSignInAccount> task =
                    GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                googleAuth(account.getIdToken());
            } catch (ApiException e) {
                mensaje("Error de autentificación con Google");
            }
        }else if (requestCode == btnFacebook.getRequestCode()) {
            callbackManager.onActivityResult(requestCode, resultCode, data);
        }

    }

    private void facebookAuth(AccessToken accessToken) {
        final AuthCredential credential = FacebookAuthProvider.getCredential(
                accessToken.getToken());
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (!task.isSuccessful()) {
                            if (task.getException() instanceof
                                    FirebaseAuthUserCollisionException) {
                                LoginManager.getInstance().logOut();
                            }
                            mensaje(task.getException().getLocalizedMessage());
                        } else {
                            verificaSiUsuarioValidado();
                        }
                    }
                });
    }

    private void googleAuth(String idToken) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken,
                null);
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            verificaSiUsuarioValidado();
                        }else{
                            mensaje(task.getException().getLocalizedMessage());
                        }
                    }
                });
    }

*/
    public void verificaSiUsuarioValidado() {
        if (auth.getCurrentUser() != null) {
            Usuarios usuarios = new Usuarios();
            usuarios.nuevo(auth.getCurrentUser());
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            db.collection("usuarios").document(auth.getCurrentUser().getEmail()).get()
                    .addOnCompleteListener(
                            new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task){
                                    if (task.isSuccessful()) {
                                        Usuario usuario = task.getResult().toObject(Usuario.class);
                                        if(usuario != null && usuario.getHogares().size() >= 2){
                                            Intent intent = new Intent(actividad, ListaHogaresActivity.class);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                                                    | Intent.FLAG_ACTIVITY_NEW_TASK
                                                    | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                            startActivity(intent);
                                            finish();
                                        }else if(usuario != null && usuario.getHogares().size() == 1){
                                            Intent intent = new Intent(actividad, VistaHogarActivity.class);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                                                    | Intent.FLAG_ACTIVITY_NEW_TASK
                                                    | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                            startActivity(intent);
                                            finish();
                                        }else if(usuario != null && usuario.getHogares().size() == 0){
                                            Intent intent = new Intent(actividad, MainActivity.class);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                                                    | Intent.FLAG_ACTIVITY_NEW_TASK
                                                    | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                            startActivity(intent);
                                            finish();
                                        }

                                    } else {
                                        Log.e("Firestore", "Error al leer", task.getException());
                                    }
                                }
                            });
        }
    }

    public void inicioSesiónCorreo() {
        if (verificaCampos()) {
            dialogo.show();
            auth.signInWithEmailAndPassword(correo, contraseña)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                verificaSiUsuarioValidado();
                            } else {
                                dialogo.dismiss();
                                mensaje(task.getException().getLocalizedMessage());
                                binding.contraseA.setText("");
                                binding.errorTextContraseA.setText("Contraseña incorrecta");

                            }
                        }
                    });
        }
    }
    public void registroCorreo() {


            auth.createUserWithEmailAndPassword(emailRegistro, passRegistro)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                verificaSiUsuarioValidado();
                            } else {

                                mensaje(task.getException().getLocalizedMessage());
                            }
                        }
                    });

    }

    private void mensaje(String mensaje) {
        Snackbar.make(contenedor, mensaje, Snackbar.LENGTH_LONG).show();
    }
    private boolean verificaCampos() {
        correo = etCorreo.getText().toString();
        contraseña = etContraseña.getText().toString();

        if (correo.isEmpty()) {
            binding.errorTextCorreo.setText("Introduce una dirección de correo");
        } else if (!correo.matches(".+@.+[.].+")) {
            binding.errorTextCorreo.setText("Introduce una dirección de correo válida");
        }else if (contraseña.isEmpty()) {
            binding.errorTextCorreo.setText("");
            binding.errorTextContraseA.setText("Introduce una contraseña");
        }
        else {
            binding.errorTextCorreo.setText("");
            binding.errorTextContraseA.setText("");
            return true;
        }

        return false;
    }


    public void reestablecerContraseña() {
        correo = etCorreo.getText().toString();
        binding.errorTextCorreo.setText("");
        if (correo.isEmpty()) {
            binding.errorTextCorreo.setText("Introduce una dirección de correo");
        } else if (!correo.matches(".+@.+[.].+")) {
            binding.errorTextCorreo.setText("Correo no válido");

        } else {
            dialogo.show();
            auth.sendPasswordResetEmail(correo)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override public void onComplete(@NonNull Task<Void> task) {
                            dialogo.dismiss();
                            if (task.isSuccessful()) {
                                mensaje("Verifica tu correo para cambiar contraseña.");
                            } else {
                                mensaje("ERROR al mandar correo para cambiar contraseña");
                            }
                        }
                    });
        }
    }


    public void firebaseUI(View v) {
        startActivity(new Intent(this, LoginActivity.class));
    }


}

