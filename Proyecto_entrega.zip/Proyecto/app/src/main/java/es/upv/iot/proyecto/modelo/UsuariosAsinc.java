package es.upv.iot.proyecto.modelo;

import com.google.firebase.auth.FirebaseUser;

import java.util.List;

import es.upv.iot.proyecto.datos.Hogar;
import es.upv.iot.proyecto.datos.Usuario;

public interface UsuariosAsinc {

    // USUARIO
    interface EscuchadorElemento{
        void onRespuesta(Usuario usuario);
    }

    interface EscuchadorTamaño{
        void onRespuesta(long tamaño);
    }

    void elemento(String id, EscuchadorElemento escuchador);

    void nuevo(FirebaseUser user);

    void borrar(String id);

    void actualiza(String id, Usuario usuario);

    void tamaño(EscuchadorTamaño escuchador);


    //LISTA HOGARES

    void actualizaHogares(String id, List<Hogar> hogares);

}
